#include <math.h>
#include <stdio.h>
#include <sys/time.h>
int main(int argc,int **argv)  
{  
    int i;  
    struct timeval start;  
    struct timeval end;  
    double timeuse;  
    char *exec_argv[4];  
    if (argc==1)  
    {  
        printf("Error!\n");  
        exit(0);  
    }  
    if (fork()==0)  //一个进程调用fork（）函数后，系统先给新的进程分配资源，例如存储数据和代码的空间。然后把原来的进程的所有值都复制到新的新进程中，只有少数值与原来的进程的值不同。相当于克隆了一个自己。
    {  
	execv(argv[1],exec_argv);  
    }  
    else 
    {  
        gettimeofday( &start, NULL ); 
	printf("starttime:%d:%d\n",start.tv_sec,start.tv_usec);
        wait(NULL);  //父进程一旦调用了wait就立即阻塞自己，由wait自动分析是否当前进程的某个子进程已经退出，如果让它找到了这样一个已经变成僵尸的子进程，wait就会收集这个子进程的信息，并把它彻底销毁后返回；如果没有找到这样一个子进程，wait就会一直阻塞在这里，直到有一个出现为止。
        gettimeofday( &end, NULL );  
	printf("endtime:%d:%d\n",end.tv_sec,end.tv_usec);
        timeuse =  ( end.tv_sec - start.tv_sec ) + (end.tv_usec - start.tv_usec)/1000;  
        printf("lasting time:%.3lfs\n",timeuse);  
    }  
    return 0;  
}  
