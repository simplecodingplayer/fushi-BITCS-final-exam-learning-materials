
#include <stdio.h> 
int main(int argc,char **argv)  
{  
	printf("Hi，my name is 戴金豆\n");
	sleep(3);
	return 0;
}
