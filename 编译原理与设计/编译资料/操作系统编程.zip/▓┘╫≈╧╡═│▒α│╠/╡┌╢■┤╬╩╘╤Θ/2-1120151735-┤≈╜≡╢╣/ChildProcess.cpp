#include <iostream>
#include <stdio.h> 
#include<windows.h>
#include<ctime>
using namespace std;  
int main(int argc,char **argv)  
{  
	printf("Hi��my name is ����\n");
	Sleep(3000);
}
