#include "stdafx.h"
#include <cstdio>
#include <cstdlib>
#include <iostream> 
#include <windows.h>
#include <psapi.h>
#include <tlhelp32.h>
#include <shlwapi.h>
#include <iomanip>
#include <string>
#pragma comment(lib,"Shlwapi.lib")
using namespace std;
/*实时地显示当前系统中内存的使用情况，
包括系统地址空间的布局，物理内存的使用情况；

实时显示实验二进程控制(ParentProcess.exe)的虚拟地址空间布局和工作集信息

相关的系统调用：
GetSystemInfo, VirtualQueryEx, VirtualAlloc, GetPerformanceInfo, GlobalMemoryStatusEx ...
*/

void showMem(MEMORYSTATUSEX status)
{
	cout << endl;
	cout << "---------------------内存信息-------------------------" << endl;
	cout << "当前物理内存使用率为：                     " << status.dwMemoryLoad << "%" << endl;
	cout << "实际物理内存大小：                         " << setprecision(3) << status.ullTotalPhys / 1024.0 / 1024 / 1024 << "GB" << endl;
	cout << "当前可用物理内存大小：                     " << setprecision(3) << status.ullAvailPhys / 1024.0 / 1024 / 1024 << "GB" << endl;
	cout << "当前提交的内存：                           " << setprecision(3) << status.ullTotalPageFile / 1024.0 / 1024 / 1024 << "GB" << endl;
	cout << "当前进程可以提交的最大内存：               " << setprecision(3) << status.ullAvailPageFile / 1024.0 / 1024 / 1024 << "GB" << endl;
	cout << "虚拟内存总量为：                           " << setprecision(3) << status.ullTotalVirtual / 1024.0 / 1024 / 1024 << "GB" << endl;
	cout << "可用虚拟内存为：                           " << setprecision(3) << status.ullAvailVirtual / 1024.0 / 1024 / 1024 << "GB" << endl;
}

void showSysInfo(SYSTEM_INFO si)
{
	cout << endl;
	cout << "---------------------系统信息-------------------------" << endl;
	cout << "内存页的大小为：                           " << si.dwPageSize / 1024 << "kb" << endl;
	cout << "每个进程可用地址空间的最小内存地址为:      0x" << si.lpMinimumApplicationAddress << endl;
	cout << "每进程可用的私有地址空间的最大内存地址为:  0x" << si.lpMaximumApplicationAddress << endl;
	cout << "能够保留地址空间区域的最小单位为:          " << si.dwAllocationGranularity / 1024 << "KB" << endl;
}

void showSysMem(PERFORMANCE_INFORMATION pi)
{
	cout << endl;
	cout << "----------------系统的存储器使用情况------------------" << endl;
	cout << "结构体的大小为:                            " << pi.cb << "B" << endl;
	cout << "系统当前提交页面总数:                      " << pi.CommitTotal << endl;
	cout << "系统可提交最大页数:                        " << pi.CommitLimit << endl;
	cout << "系统历史提交页面峰值:                      " << pi.CommitPeak << endl;
	cout << "按页分配总物理内存:                        " << pi.PhysicalTotal << endl;
	cout << "可用物理内存:                              " << pi.PhysicalAvailable << endl;
	cout << "系统Cache容量大小:                         " << pi.SystemCache << endl;
	cout << "内存总量(按页)为:                          " << pi.KernelTotal << endl;
	cout << "分页池的大小为:                            " << pi.KernelPaged << endl;
	cout << "非分页池的大小为:                          " << pi.KernelNonpaged << endl;
	cout << "页的大小为:                                " << pi.PageSize << endl;
	cout << "打开的句柄总数:                            " << pi.HandleCount << endl;
	cout << "进程总数为:                                " << pi.ProcessCount << endl;
	cout << "线程总数为:                                " << pi.ThreadCount << endl;
}

void showEveryProc()
{
	printf("------------------各个进程的信息----------------------\n");
	PROCESSENTRY32 pe;
	/*
	typedef   struct   PROCESSENTRY32   {
	DWORD   dwSize;   //   结构大小；
	DWORD   cntUsage;   //   此进程的引用计数；
	DWORD   th32ProcessID;   //   进程ID;
	DWORD   th32DefaultHeapID;   //   进程默认堆ID；
	DWORD   th32ModuleID;   //   进程模块ID；
	DWORD   cntThreads;   //   此进程开启的线程计数；
	DWORD   th32ParentProcessID;//   父进程ID；
	LONG   pcPriClassBase;   //   线程优先权；
	DWORD   dwFlags;   //   保留；
	char   szExeFile[MAX_PATH];   //   进程全名；
	}   PROCESSENTRY32;
	*/
	pe.dwSize = sizeof(pe);
	HANDLE hProcessSnap = ::CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);//为当前系统拍快照，以便打印当前进程信息
	BOOL bMore = ::Process32First(hProcessSnap, &pe);
	/*
	process32First是一个进程获取函数，
	当我们利用函数CreateToolhelp32Snapshot()获得当前运行进程的快照后，
	我们可以利用process32First函数来获得第一个进程的句柄。
	此函数往往和
	Process32Next(
	Handle hsnapShot,
	LPPROCESSENTRY32 lppe)
	搭配使用，用来枚举当前系统快照相关的所有进程。
	函数返回值:成功返回true,否则返回false.
	*/
	while (bMore)
	{
		HANDLE hP = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe.th32ProcessID);
		PROCESS_MEMORY_COUNTERS pmc;
		ZeroMemory(&pmc, sizeof(pmc));

		if (GetProcessMemoryInfo(hP, &pmc, sizeof(pmc)) == TRUE)
			/*
			BOOL WINAPI GetProcessMemoryInfo(
			_In_  HANDLE                   Process,
			_Out_ PPROCESS_MEMORY_COUNTERS ppsmemCounters,
			_In_  DWORD                    cb
			);
			*/
		{
			cout << "进程ID:\t\t" << pe.th32ProcessID << endl;
			cout << "进程名称:\t\t";
			//wcout << pe.szExeFile <<endl;
			//cout << WideCharToMultiByte(pe.szExeFile) << endl;
			int iSize;
			iSize = WideCharToMultiByte(CP_ACP, 0, pe.szExeFile, -1, NULL, 0, NULL, NULL);
			char procName[100];
			WideCharToMultiByte(CP_ACP, 0, pe.szExeFile, -1, procName, iSize, NULL, NULL);
			cout << procName << endl;
			cout << "虚拟内存的大小为:\t" << pmc.WorkingSetSize / 1024 << "KB" << endl << endl;
		}
		bMore = ::Process32Next(hProcessSnap, &pe);
	}
}

int findIDByName(char *procName)
{
	PROCESSENTRY32 pe;
	pe.dwSize = sizeof(pe);
	HANDLE hProcessSnap = ::CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);//为当前系统拍快照，以便打印当前进程信息
	BOOL bMore = ::Process32First(hProcessSnap, &pe);
	while (bMore)
	{
		HANDLE hP = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe.th32ProcessID);
		PROCESS_MEMORY_COUNTERS pmc;
		ZeroMemory(&pmc, sizeof(pmc));

		if (GetProcessMemoryInfo(hP, &pmc, sizeof(pmc)) == TRUE)
		{

			int iSize;
			iSize = WideCharToMultiByte(CP_ACP, 0, pe.szExeFile, -1, NULL, 0, NULL, NULL);
			char procNameTmp[100];
			WideCharToMultiByte(CP_ACP, 0, pe.szExeFile, -1, procNameTmp, iSize, NULL, NULL);
			if (strcmp(procNameTmp, procName) == 0)
			{
				cout << "\nThe id of the Process is " << pe.th32ProcessID << "." << endl << endl;
				//cout << "in:  " << procName << "    " << "find:  " << procNameTmp << endl;
				return pe.th32ProcessID;
			}
		}
		bMore = ::Process32Next(hProcessSnap, &pe);
	}
	cout << "Did not find the process!" << endl;
	return 0;
}

void findNameById(int procID)
{
	PROCESSENTRY32 pe;
	pe.dwSize = sizeof(pe);
	HANDLE hProcessSnap = ::CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);//为当前系统拍快照，以便打印当前进程信息
	BOOL bMore = ::Process32First(hProcessSnap, &pe);
	while (bMore)
	{
		HANDLE hP = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe.th32ProcessID);
		PROCESS_MEMORY_COUNTERS pmc;
		ZeroMemory(&pmc, sizeof(pmc));

		if (GetProcessMemoryInfo(hP, &pmc, sizeof(pmc)) == TRUE)
		{

			int iSize;
			iSize = WideCharToMultiByte(CP_ACP, 0, pe.szExeFile, -1, NULL, 0, NULL, NULL);
			char procNameTmp[100];
			WideCharToMultiByte(CP_ACP, 0, pe.szExeFile, -1, procNameTmp, iSize, NULL, NULL);
			if (pe.th32ProcessID == procID)
			{
				cout << "\nThe name of the Process is " << procNameTmp << "." << endl << endl;
				return;
			}
		}
		bMore = ::Process32Next(hProcessSnap, &pe);
	}
	cout << "Did not find the process!" << endl;
	return;
}

//显示保护标记，该标记表示允许应用程序对内存进行访问的类型
inline bool TestSet(DWORD dwTarget, DWORD dwMask)
{
	return ((dwTarget &dwMask) == dwMask);
}

#define SHOWMASK(dwTarget,type) if(TestSet(dwTarget,PAGE_##type)){cout << "," << #type;}

void ShowProtection(DWORD dwTarget)
{//定义的页面保护类型
	SHOWMASK(dwTarget, READONLY);
	SHOWMASK(dwTarget, GUARD);
	SHOWMASK(dwTarget, NOCACHE);
	SHOWMASK(dwTarget, READWRITE);
	SHOWMASK(dwTarget, WRITECOPY);
	SHOWMASK(dwTarget, EXECUTE);
	SHOWMASK(dwTarget, EXECUTE_READ);
	SHOWMASK(dwTarget, EXECUTE_READWRITE);
	SHOWMASK(dwTarget, EXECUTE_WRITECOPY);
	SHOWMASK(dwTarget, NOACCESS);
}

//遍历整个虚拟内存，并显示各内存区属性的工作程序的方法
void WalkVM(HANDLE hProcess)
{
	SYSTEM_INFO si;	//系统信息结构
	ZeroMemory(&si, sizeof(si));	//初始化
	GetSystemInfo(&si);	//获得系统信息

	MEMORY_BASIC_INFORMATION mbi;	//进程虚拟内存空间的基本信息结构
	ZeroMemory(&mbi, sizeof(mbi));	//分配缓冲区，用于保存信息

									//循环整个应用程序地址空间
	LPCVOID pBlock = (LPVOID)si.lpMinimumApplicationAddress;
	while (pBlock < si.lpMaximumApplicationAddress)
	{
		//获得下一个虚拟内存块的信息
		if (VirtualQueryEx(
			hProcess,	//相关的进程
			pBlock,		//开始位置
			&mbi,		//缓冲区
			sizeof(mbi)) == sizeof(mbi))	//长度的确认，如果失败返回0
		{
			//计算块的结尾及其长度
			LPCVOID pEnd = (PBYTE)pBlock + mbi.RegionSize;//该虚存区的大小
			TCHAR szSize[MAX_PATH];
			//将数字转换成字符串
			StrFormatByteSize(mbi.RegionSize, szSize, MAX_PATH);

			//显示块地址和长度
			cout.fill('0');
			cout << hex << setw(8) << (DWORD)pBlock << "-" << hex << setw(8) << (DWORD)pEnd;

			int iSize;
			iSize = WideCharToMultiByte(CP_ACP, 0, szSize, -1, NULL, 0, NULL, NULL);
			char szSizeTmp[100];
			WideCharToMultiByte(CP_ACP, 0, szSize, -1, szSizeTmp, iSize, NULL, NULL);
			cout << (lstrlen(szSize) == 7 ? "(" : "(") << szSizeTmp << ")";

			//显示块的状态
			switch (mbi.State)//该区域是提交，空闲还是预留
			{
			case MEM_COMMIT:
				printf("已提交");
				break;
			case MEM_FREE:
				printf("空闲 ");
				break;
			case MEM_RESERVE:
				printf("已预留");
				break;
			}

			//显示保护
			if (mbi.Protect == 0 && mbi.State != MEM_FREE)//protect：该区域设置的访问方式，只能是AllocationProtect的标志之一或是其中几个组合
			{
				mbi.Protect = PAGE_READONLY;
			}
			ShowProtection(mbi.Protect);

			//显示类型
			switch (mbi.Type)
			{
			case MEM_IMAGE:
				printf(", \t  Image\t");//可执行映像,如EXE，DLL文件
				break;
			case MEM_MAPPED:
				printf(", \t  Mapped\t");//内存映射文件
				break;
			case MEM_PRIVATE:
				printf(", \t  Private\t");//内存私有文件
				break;
			}

			//检验可执行的映像
			TCHAR szFilename[MAX_PATH];
			if (GetModuleFileName(
				(HMODULE)pBlock,			//实际虚拟内存的模块句柄
				szFilename,					//完全指定的文件名称
				MAX_PATH) > 0)				//实际使用的缓冲区长度
			{
				//除去路径并显示
				PathStripPath(szFilename);
				int iSize;
				iSize = WideCharToMultiByte(CP_ACP, 0, szFilename, -1, NULL, 0, NULL, NULL);
				char szFilenameTmp[100];
				WideCharToMultiByte(CP_ACP, 0, szFilename, -1, szFilenameTmp, iSize, NULL, NULL);
				printf(", Module:%s", szFilenameTmp);
			}

			printf("\n");
			//移动块指针以获得下一个块
			pBlock = pEnd;
		}
	}
}



void showLab2()
{
	cout << "-------进程虚拟地址空间布局和工作集信息查询---------\n" << endl;
	int flag = 0;
	int procID;
	cout << "请选择：" << endl;
	cout << "1.输入进程ID查看进程虚拟地址空间信息" << endl;
	cout << "2.输入进程名称查看进程虚拟地址空间信息" << endl;
	cin >> flag;
	while (true)
	{
		if (flag == 1 || flag == 2)
			break;
		else
		{
			cout << "输入错误，请重新输入：" << endl;
			cin >> flag;
		}

	}
	if (flag == 1)
	{
		cout << "输入要查询的进程ID:" << endl;
		char procName[100];
		cin >> procID;
		findNameById(procID);

	}
	else if (flag == 2)
	{
		cout << "输入要查询的进程名称:" << endl;
		char procName[100];
		cin >> procName;
		procID = findIDByName(procName);
	}
	else
		cout << "输入错误，请重新输入：" << endl;
	HANDLE hP = OpenProcess(PROCESS_ALL_ACCESS, FALSE, procID);
	WalkVM(hP);
}

int main(int argc, char* argv[])
{
	MEMORYSTATUSEX status;
	/*
	typedef struct _MEMORYSTATUSEX {
	DWORD     dwLength;//结构体的大小，在使用GlobalMemoryStatusEx之前必须设置此值
	DWORD     dwMemoryLoad;//内存使用率，0-100
	DWORDLONG ullTotalPhys;//实际物理内存大小，in bytes
	DWORDLONG ullAvailPhys;//当前可用物理内存大小，in bytes
	DWORDLONG ullTotalPageFile;//当前提交的内存，受限于系统或者当前进程，in bytes
	DWORDLONG ullAvailPageFile;//当前进程可以提交的最大内存，in bytes
	DWORDLONG ullTotalVirtual;//虚拟内存总量，in bytes
	DWORDLONG ullAvailVirtual;//可用虚拟内存，in bytes
	DWORDLONG ullAvailExtendedVirtual;//保留，该值总为0
	} MEMORYSTATUSEX, *LPMEMORYSTATUSEX;
	*/
	status.dwLength = sizeof(status);
	GlobalMemoryStatusEx(&status);
	/*输出当前内存使用情况*/
	showMem(status);

	SYSTEM_INFO si;
	/*
	typedef struct _SYSTEM_INFO { // sinf
	union {
	DWORD  dwOemId;//已经废弃，保留是为了兼容
	struct {
	WORD wProcessorArchitecture;//指定中央处理器的体系结构
	WORD wReserved;//保留供将来使用
	};
	};
	DWORD  dwPageSize;//指定页面的大小和页面保护和委托的颗粒。
	LPVOID lpMinimumApplicationAddress;//可访问最低内存地址
	LPVOID lpMaximumApplicationAddress;//可访问最高内存地址
	DWORD  dwActiveProcessorMask;//指定一个系统中配置了中央处理器的掩码
	DWORD  dwNumberOfProcessors;//系统中处理器的数目
	DWORD  dwProcessorType;//系统中中央处理器的类型
	DWORD  dwAllocationGranularity;//已被分配虚拟内存空间粒度
	WORD  wProcessorLevel;//win NT：指定系统体系结构依赖的处理器级别
	WORD  wProcessorRevision;//处理器类型

	} SYSTEM_INFO;
	*/
	ZeroMemory(&si, sizeof(si));
	GetSystemInfo(&si);
	/*输出系统信息结构*/
	showSysInfo(si);

	PERFORMANCE_INFORMATION pi;
	/*
	typedef struct _PERFORMANCE_INFORMATION {
	DWORD  cb;//结构体大小
	SIZE_T CommitTotal;//系统当前提交页面总数
	SIZE_T CommitLimit;//系统可提交最大页数
	SIZE_T CommitPeak;//系统历史提交页面峰值
	SIZE_T PhysicalTotal;//按页分配总物理内存
	SIZE_T PhysicalAvailable;//可用物理内存
	SIZE_T SystemCache;系统Cache容量大小
	SIZE_T KernelTotal;//内存总量，包括分页和非分页池
	SIZE_T KernelPaged;//分页池大小
	SIZE_T KernelNonpaged;//非分页池大小
	SIZE_T PageSize;//页的大小
	DWORD  HandleCount;//打开的句柄总数
	DWORD  ProcessCount;//进程总数
	DWORD  ThreadCount;//线程总数
	} PERFORMANCE_INFORMATION, *PPERFORMANCE_INFORMATION;
	*/
	pi.cb = sizeof(pi);
	GetPerformanceInfo(&pi, sizeof(pi));
	/*输出系统存储器使用情况*/
	showSysMem(pi);

	/*打印每个进程的信息*/
	showEveryProc();

	/*显示实验2进程信息*/
	showLab2();

	system("pause");
}