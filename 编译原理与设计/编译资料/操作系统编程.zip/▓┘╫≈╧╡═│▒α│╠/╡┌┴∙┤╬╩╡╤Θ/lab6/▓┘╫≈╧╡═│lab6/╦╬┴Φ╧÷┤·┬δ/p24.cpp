# include <windows.h>
# include <stdio.h>
# include <stdlib.h>
# include <time.h>
#include <ctype.h> 
#include<string.h>
typedef struct 
{
	int n;
	char name[10];
	char age[3];
	char tel[20];
	char mail[20];
} buf;
buf *pData,*out;
HANDLE SEM_FULL;
HANDLE SEM_EMPTY;
HANDLE SEM_MUTEX;  
HANDLE hMap;
int main(int argc,char*argv[]) 
{
	        int nClone;
	        int time1;
			sscanf(argv[1] , "%d" , &nClone) ;
			SEM_EMPTY=OpenSemaphore(SEMAPHORE_ALL_ACCESS,NULL,"EMPTY");
			SEM_FULL=OpenSemaphore(SEMAPHORE_ALL_ACCESS,NULL,"FULL");
			SEM_MUTEX=OpenSemaphore(SEMAPHORE_ALL_ACCESS,NULL,"MUTEX");

			hMap = OpenFileMapping(FILE_MAP_WRITE,FALSE,"buffer");
			pData = (buf*)MapViewOfFile (hMap, FILE_MAP_WRITE, 0, 0, sizeof(buf)*5);
            out=pData;
            char name[10]={'\0'};
			char age[3]={'\0'};
			char tel[20]={'\0'};
			char mail[20]={'\0'};
			strcpy((name),pData->name);
			printf("%s\n",name);
			strcpy((age),pData->age);
			strcpy((tel),pData->tel);
			strcpy((mail),pData->mail);
			//p �����ź���
			WaitForSingleObject(SEM_EMPTY, INFINITE);
			WaitForSingleObject(SEM_MUTEX, INFINITE);
			
			(pData->n)++;
			(pData+(pData->n))->n=nClone-6;
			strcpy((pData+(pData->n))->name,name);
			strcpy((pData+(pData->n))->age,age);
			strcpy((pData+(pData->n))->tel,tel);
			strcpy((pData+(pData->n))->mail,mail);
			//���ʱ��
			SYSTEMTIME curtime;
			GetSystemTime(&curtime);
			//���״̬
			printf(" No.%d producer put product at %02d:%02d:%02d:%03d.\n "  
			          ,nClone-6,curtime.wHour,curtime.wMinute,curtime.wSecond,curtime.wMilliseconds);
			printf("   Now the buffer is as follows: ");
			for (int j=1;j<=4;j++)
			{
				printf("%4d",(out+j)->n);
			}
			printf("\n");

			//�ͷ��ź���
			ReleaseSemaphore(SEM_MUTEX,1,NULL);
			ReleaseSemaphore(SEM_FULL,1,NULL);	

			//�رվ��
			CloseHandle(SEM_MUTEX);
			CloseHandle(SEM_EMPTY);
			CloseHandle(SEM_FULL);
            CloseHandle(hMap);

			//����ȴ�
		    srand(clock());
			time1 = rand()%3000;
			Sleep(time1);
}
