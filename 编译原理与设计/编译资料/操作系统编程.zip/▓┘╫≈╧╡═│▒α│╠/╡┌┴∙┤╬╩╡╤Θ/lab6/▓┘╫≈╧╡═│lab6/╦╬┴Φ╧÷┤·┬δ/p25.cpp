# include <windows.h>
# include <stdio.h>
# include <stdlib.h>
# include <time.h>
#include <ctype.h> 
#include<string.h>
typedef struct 
{
	int n;
	char name[10];
	char age[3];
	char tel[20];
	char mail[20];
} buf;
buf *pData,*out;
HANDLE SEM_FULL;
HANDLE SEM_EMPTY;
HANDLE SEM_MUTEX;  
HANDLE hMap;
int main(int argc,char*argv[]) 
{
			int nClone;
    		sscanf(argv[1] , "%d" , &nClone) ;
    		//printf("%nclone=d\n",nClone);
    		SEM_EMPTY=OpenSemaphore(SEMAPHORE_ALL_ACCESS,NULL,"EMPTY");
			SEM_FULL=OpenSemaphore(SEMAPHORE_ALL_ACCESS,NULL,"FULL");
			SEM_MUTEX=OpenSemaphore(SEMAPHORE_ALL_ACCESS,NULL,"MUTEX");
            //printf("xsds\n");
			hMap = OpenFileMapping(FILE_MAP_WRITE,FALSE,"buffer");
			pData = (buf*)MapViewOfFile (hMap, FILE_MAP_WRITE, 0, 0, sizeof(buf)*5);
            out=pData;
            if(pData==NULL)
            //printf("wrong!\n");
			WaitForSingleObject(SEM_FULL, INFINITE);
			WaitForSingleObject(SEM_MUTEX, INFINITE);
			srand(clock());
			//����ȴ�
			int time1 = rand()%3000;
			Sleep(time1);
			if(pData->n==0)
			{Sleep(300000);}
			FILE *fp,*fp1;
			SYSTEMTIME curtime;
			GetSystemTime(&curtime);
            char k1=48+nClone-12;
            //printf("%c\n",k1);
            char k2[6];
            char k3=48+(pData+1)->n;
           // printf("%c\n",k3);
            char name[10]={'\0'};
			char age[3]={'\0'};
			char tel[20]={'\0'};
			char mail[20]={'\0'};
			strcpy((name),(pData+1)->name);
			strcpy((age),(pData+1)->age);
			strcpy((tel),(pData+1)->tel);
			strcpy((mail),(pData+1)->mail);
            //printf("%c\n",k3);
            k2[0]=k1;
            k2[1]='.';
            k2[2]='t';
            k2[3]='x';
            k2[4]='t';
            k2[5]='\0';
            char ch='0';
			char str[20]={"E:\\1\\client"};
			strcat(str,k2);
			//printf("%s\n",str);
			if((fp = fopen(str,"w+")) == NULL)//����Ҫɨ����ļ�
	        {
	         	printf("cannot open file\n");
	  			exit(0);
			}
			fprintf(fp,"%c",k3);
			fclose(fp);
            for(int j=1;j<=3;j++) 
            {
			  
			   (pData+j)->n=(pData+j+1)->n;
			   strcpy((pData+j)->name,(pData+j+1)->name);
			   strcpy((pData+j)->age,(pData+j+1)->age);
			   strcpy((pData+j)->tel,(pData+j+1)->tel);
			   strcpy((pData+j)->mail,(pData+j+1)->mail);
				}
			(pData+4)->n=0;
			(pData->n)--;
			for(int i=0;i<10;i++)
			(pData+4)->name[i]='\0';
            
			//�����ǰ��Ϣ
			printf(" No.%d consumer get product at %02d:%02d:%02d:%03d.\n"
				     ,nClone-12,curtime.wHour,curtime.wMinute,curtime.wSecond,curtime.wMilliseconds);
            printf("   Now the buffer is as follows: ");
			for (int j=1;j<=4;j++)
			{
				printf("%4d",(out+j)->n);
			}
			printf("\n");
            printf("the driver is %s\n",name);
			//�ͷ��ź�
			
			if((fp = fopen("E:\\1\\Client.txt","r+")) == NULL)//����Ҫɨ����ļ�
	        {
	         	printf("cannot open file\n");
	  			exit(0);
			}
			ch='0';
			for(;ch!=EOF;)
			{
				ch=fgetc(fp);
				}
			fprintf(fp,"%8d ",nClone-12);
			fprintf(fp,"%8s ",name);
			fprintf(fp,"%02d:%02d:%02d:%03d \n",curtime.wHour,curtime.wMinute,curtime.wSecond,curtime.wMilliseconds);
			fclose(fp);
			ReleaseSemaphore(SEM_MUTEX,1,NULL);
			ReleaseSemaphore(SEM_EMPTY,1,NULL);

			//�رվ��
			CloseHandle(SEM_MUTEX);
			CloseHandle(SEM_EMPTY);
			CloseHandle(SEM_FULL);
            CloseHandle(hMap);
            
}
