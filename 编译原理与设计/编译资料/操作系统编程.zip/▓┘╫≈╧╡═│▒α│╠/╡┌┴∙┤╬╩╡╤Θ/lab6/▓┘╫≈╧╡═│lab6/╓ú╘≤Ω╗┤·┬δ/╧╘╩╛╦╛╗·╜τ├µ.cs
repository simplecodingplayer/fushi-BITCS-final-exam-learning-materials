﻿//<郑泽昊>
using System;
using System.Windows.Forms;
using System.IO;

namespace 模拟打车软件
{
    public partial class 显示司机界面 : Form
    {
        public 显示司机界面()
        {
            InitializeComponent();
            this.FormClosing += (o, e) =>
            {
                if (e.CloseReason == CloseReason.ApplicationExitCall)
                {
                    Environment.Exit(0);
                }
                else if (e.CloseReason == CloseReason.UserClosing)
                {
                    e.Cancel = MessageBox.Show("要退出进程请点击“退出软件按钮”", this.Text, MessageBoxButtons.OK) == DialogResult.OK;
                }
            };
        }
        int flag = 0;
        private void ReadTextFile(string filePath)//一个函数显示所有内容
        {
            foreach (Control ctrl in Controls)
            {
                if (ctrl is TextBox)
                    ctrl.Text = "";
            }
            //MessageBox.Show("清空完毕");
            // 读入文本文件的所有行
            string[] lines = File.ReadAllLines(filePath);
            // 在textBox1中显示文件内容
            textBox1.AppendText("司机编号 司机姓名 年龄 电话 邮箱" + Environment.NewLine);
            foreach (string line in lines)
            {
                //if(line == )
                textBox1.AppendText(line + Environment.NewLine);
            }
            if(flag++ == 0)MessageBox.Show("所有司机信息显示成功");
            else MessageBox.Show("所有司机信息刷新成功");
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        int buttonflag = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            if (buttonflag++ == 0) button1.Text = "点击刷新司机信息";
            ReadTextFile("E:\\1\\test.txt");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            显示总体界面 f = new 显示总体界面();
            f.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
//</郑泽昊>