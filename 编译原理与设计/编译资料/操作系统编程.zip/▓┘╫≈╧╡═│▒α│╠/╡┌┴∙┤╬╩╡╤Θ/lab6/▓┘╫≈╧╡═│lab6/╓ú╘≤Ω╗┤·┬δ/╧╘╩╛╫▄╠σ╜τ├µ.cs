﻿//<郑泽昊>
using System;
using System.Windows.Forms;

namespace 模拟打车软件
{
    public partial class 显示总体界面 : Form
    {
        public 显示总体界面()
        {
            InitializeComponent();
            this.FormClosing += (o, e) =>
            {
                if(e.CloseReason == CloseReason.ApplicationExitCall)
                {
                    System.Environment.Exit(0);
                }
                else if (e.CloseReason == CloseReason.UserClosing)
                {
                    e.Cancel = MessageBox.Show("要退出进程请点击“退出软件按钮”", this.Text, MessageBoxButtons.OK) == DialogResult.OK;
                }
            };
        }

        private void button1_Click(object sender, EventArgs e)
        {
            显示司机界面 f = new 显示司机界面();
            f.Show();
            this.Hide();
            //Application.Run(new 显示司机界面());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            显示乘客界面 f = new 显示乘客界面();
            f.Show();
            this.Hide();
        }
    }
}
//</郑泽昊>