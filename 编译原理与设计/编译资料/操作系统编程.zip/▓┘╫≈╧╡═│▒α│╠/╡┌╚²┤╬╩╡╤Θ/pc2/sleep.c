/*生产者*/
#include "head.h"
main(int argc,char * argv[])
{
int s=3000000;
usleep(s);
}


