#ifndef head_h
#define head_h
//ipcrm -a
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <stdio.h>
#include<sys/wait.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>

#define KEY 1235
#define SEM_ALL_KEY 1234
#define SEM_EMPTY 0
#define SEM_FULL 1
#define SEM_MUTEX 2

#define PRODUCTOR_NUM 3
#define PRODUCTOR_TIMES 4
#define CONSUMER_NUM 4
#define CONSUMER_TIMES 3
#define BUFFER_NUM 4

char chr[4]={'-','D','X','M'};

void p(int sem_id, int sem_num)
{
        struct sembuf xx;
        xx.sem_num=sem_num;
        xx.sem_op=-1;
	xx.sem_flg=0;
        semop(sem_id, &xx, 1);
}

void v(int sem_id, int sem_num)
{
        struct sembuf xx;
        xx.sem_num=sem_num;
        xx.sem_op=1;
	xx.sem_flg=0;
        semop(sem_id, &xx, 1);
}

struct queue{
	int num;
	int write;
	int read;
	int n;
};

int createQueue()
{
        int shmid;
        shmid = shmget(KEY, sizeof(struct queue)*BUFFER_NUM,IPC_CREAT | IPC_EXCL | 0666);
	// IPC_CREAT当shmflg&IPC_CREAT为真时，如果内核中不存在键值与key相等的共享内存，则新建一个共享内存；
	//IPC_CREAT|IPC_EXCL：如果存在这样的共享内存，返回此共享内存的标识符;如果内核中不存在键值 与key相等的共享内存，则新建一个共享内存；如果存在这样的共享内存则报错
        if(shmid<0)
		return -1;
        else 
		return shmid;
}

void removeQueue(int id)
{
	shmctl(id, IPC_RMID, 0);
	/*
	int shmctl(int shmid, int cmd, struct shmid_ds *buf)
	 	
	shmid:共享内存标识符
	cmd	
		IPC_STAT：得到共享内存的状态，把共享内存的shmid_ds结构复制到buf中
		IPC_SET：改变共享内存的状态，把buf所指的shmid_ds结构中的uid、gid、mode复制到共享内存的shmid_ds结构内
		IPC_RMID：删除这片共享内存
	buf	
		共享内存管理结构体。
	*/
}

struct queue *getQueue()
{
        int shmid;
        shmid = shmget(KEY, sizeof(struct queue)*4, 0);
        if (shmid < 0) 
		return NULL;

        struct queue *q=(struct queue *)shmat(shmid, 0, 0);
        if (q < (struct queue *)0 ) 
		return NULL;
        return q;
}

#endif

