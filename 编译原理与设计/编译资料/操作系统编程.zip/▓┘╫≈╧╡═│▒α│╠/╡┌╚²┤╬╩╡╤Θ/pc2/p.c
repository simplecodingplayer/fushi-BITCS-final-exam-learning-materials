/*生产者*/
#include "head.h"
int main(int argc,char * argv[])
{
	struct queue *buf,*out;
	int sem_id = semget(SEM_ALL_KEY,3, IPC_CREAT|0660);
	int i,j;
	buf = getQueue();//打开共享主存
	out = buf;
	for(i=0;i<PRODUCTOR_TIMES;i++)
	{
		p(sem_id, SEM_EMPTY);	
		p(sem_id, SEM_MUTEX);				
		//获取当前时间
		struct timeval curtime;
		gettimeofday(&curtime,NULL);
		int tt=curtime.tv_usec%3+1;

		(buf+buf->write)->n=tt;//放入产品
		buf->write=(buf->write+1)%BUFFER_NUM;//产品数+1
		buf->num++;
		//输出信息
		printf("%s put product  %c ",argv[0],chr[tt]);
		printf("  Now the buffer is ");
		for(j=0;j<BUFFER_NUM;j++)
			printf("%c ",chr[(out+j)->n]);
		printf("\n");
		v(sem_id, SEM_MUTEX);	//V(MUTEX)
		v(sem_id, SEM_FULL);	//V(FULL)，释放一个FULL，即往里面写了一个数据

		if(i==PRODUCTOR_TIMES-1)
			printf("%s fineshing product!\n",argv[0]);
		int ran=1000*(curtime.tv_usec%3)+curtime.tv_usec%1000;
		usleep(ran*1000);
	}
	
}


