/*消费者*/
#include "head.h"
int main(int argc,char * argv[])
{
	struct queue *buf,*out;
	int sem_id = semget(SEM_ALL_KEY, 3, IPC_CREAT|0660);
	int i,j;
	buf = getQueue();//打开共享主存
	out = buf;
	for(i=0;i<CONSUMER_TIMES;i++)
	{
		p(sem_id, SEM_FULL);	
		p(sem_id, SEM_MUTEX);	
		int tt=(buf+buf->read)->n;
		(buf+buf->read)->n=0;//取出产品后缓冲区置0
		buf->num--;//产品数-1
		buf->read=(buf->read+1)%BUFFER_NUM;
		//获取当前时间
		struct timeval curtime;
		gettimeofday(&curtime,NULL);
		//输出信息
		printf("%s get product  %c ",argv[0],chr[tt]);
		printf("  Now the buffer is ");
		for(j=0;j<BUFFER_NUM;j++)
			printf("%c ",chr[(out+j)->n]);
		printf("\n");
		v(sem_id, SEM_MUTEX);	//V(MUTEX)
		v(sem_id, SEM_EMPTY);	//V(EMPTY)
		
		if(i==CONSUMER_TIMES-1)
			printf("%s fineshing consume!\n",argv[0]);
		int ran=1000*(curtime.tv_usec%3)+curtime.tv_usec%1000;
		usleep(ran*1000);
	}
	
}

