//主进程
#include "head.h"
int main()
{
	int id = semget(SEM_ALL_KEY, 3, IPC_CREAT|0660);
	/*
	
	int semget(key_t key,int nsems,int semflg)
	获取与某个键关联的信号量集标识。
	key：所创建或打开信号量集的键值。
	nsems：创建的信号量集合中的信号量的个数，该参数只在创建信号量集时有效。
	semflg：调用函数的操作类型，也可用于设置信号量集的访问权限，创建信号量集合;0660最左边这个0表示后面的660是个8进制数。
	后面的三个数依次表示对这个sem的操作权限。其中第一个数表示创建者的操作权限，第二个数表示同组人的操作权限，第三个数表示其他人的操作权限。操作权限用4表示读，2表示写，6表示可读也可写，0表示不能读也不能写。    
	IPC_CREAT   如果共享内存不存在，则创建一个共享内存，否则打开操作。 
	IPC_EXCL     只有在共享内存不存在的时候，新的共享内存才建立，否则就产生错误。
	*/
	//初始化信号量集合
	semctl(id, SEM_EMPTY, SETVAL, BUFFER_NUM);
	semctl(id, SEM_FULL, SETVAL, 0);
	semctl(id, SEM_MUTEX, SETVAL, 1);
	int shmid = createQueue();	//创建共享主存
	struct queue *buf = getQueue();//打开共享主存
	buf->num=0;
	buf->read=0;
	buf->write=0;
	if(shmid<0)
	{
		perror("create shm error.");
		exit(1);
	}
	//生成生产者进程
	if(fork()==0)
		execl("p", "producer1", NULL);
	if(fork()==0)
		execl("p", "producer2", NULL);
	if(fork()==0)
		execl("p", "producer3", NULL);
	//生成消费者进程
	if(fork()==0)
		execl("c", "consumer1", NULL);
	if(fork()==0)
		execl("c", "consumer2", NULL);
	if(fork()==0)
		execl("c", "consumer3", NULL);
	if(fork()==0)
		execl("c", "consumer4", NULL);
	//等待子进程
	int stat,i;
	for(i=0;i<7;i++)
		wait(&stat);
		/*
		进程一旦调用了 wait，就立即阻塞自己，由wait自动分析是否当前进程的某个子进程已经退出，
		如果让它找到了这样一个已经变成僵尸的子进程，wait 就会收集这个子进程的信息， 并把它彻底销毁后返回；如果没有找到这样一个子进程，wait就会一直阻塞在这里，直到有一个出现为止。
		*/
	removeQueue(shmid);//释放共享主存
	return 0;
}





