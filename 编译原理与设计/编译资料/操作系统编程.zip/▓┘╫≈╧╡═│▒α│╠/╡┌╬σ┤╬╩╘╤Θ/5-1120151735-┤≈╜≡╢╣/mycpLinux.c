#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <dirent.h>
#include <utime.h>
#include <time.h>
#define LENS 1024
void cpf(char *src, char *des);
void cpd(char *src, char *des);
void ct(char *src, char *des);

int main(int argc, char **argv)
{
	struct utimbuf timeSrc;
	struct stat s_file;
	/*struct stat { 
		 dev_t     st_dev; // 文件所在设备ID 
		 ino_t     st_ino;     // 结点(inode)编号  
		 mode_t    st_mode;    // 保护模式 
		 nlink_t   st_nlink;   // 硬链接个数  
		 uid_t     st_uid;     // 所有者用户ID  
		 gid_t     st_gid;     // 所有者组ID  
		 dev_t     st_rdev;    // 设备ID(如果是特殊文件) 
		 off_t     st_size;    // 总体尺寸，以字节为单位 
		 blksize_t st_blksize; // 文件系统 I/O 块大小
		 blkcnt_t  st_blocks;  // 已分配 512B 块个数
		 time_t    st_atime;   // 上次访问时间 
		 time_t    st_mtime;   // 上次更新时间 
		 time_t    st_ctime;   // 上次状态更改时间 
	}; */ 
	if(argc != 3)
	{
		printf("param error!'\n");
		exit(0);	
	}
	else
	{
		int fd;
		if( lstat(argv[1],&s_file) == -1 )
		/*
		int lstat(
		const char *path, //文件路径名。
		struct stat *buf//文件描述词。
		);*/
		{	
			perror("lstat");
			exit(0);
		}
		if(S_ISDIR(s_file.st_mode))
		{
			//目录文件
			mkdir(argv[2], s_file.st_mode);
			cpd(argv[1], argv[2]);
			//ct(argv[1], argv[2]);
		}
		else 
		{
			cpf(argv[1], argv[2]);
		}
	}
	stat(argv[1], &s_file);
	timeSrc.actime = s_file.st_atime;
	timeSrc.modtime = s_file.st_mtime;
	utime(argv[2], &timeSrc);
	/*
	int utime(
	const char *filename, //文件名
	const struct utimbuf *times//记录时间的结构体
	);
	struct utimbuf {
	               time_t actime;       // access time 
	               time_t modtime;      // modification time 
	              };
	*/
	printf("copy finished!\n");	
	return 0;
}

void cpd(char *src, char *des)
{
	DIR *dirptr = NULL;
	/*struct dirent
	{
	long d_ino; // 索引节点号 
	off_t d_off; // 在目录文件中的偏移 
	unsigned short d_reclen;//  文件名长 
	unsigned char d_type; //  文件类型 
	char d_name [NAME_MAX+1];// 文件名，最长255字符 
	}*/
	struct dirent *dr_file = NULL;
	/*
	struct dirent
	{
	long d_ino;  //inode number 索引节点号 
	off_t d_off;  //offset to this dirent 在目录文件中的偏移 
	unsigned short d_reclen; // length of this d_name 文件名长 
	unsigned char d_type; // the type of d_name 文件类型 
	char d_name [NAME_MAX+1]; //  文件名，最长255字符 
	}
	*/
	struct stat s_file;
	struct utimbuf timeSrc;
	struct timeval times[2];
	
	char sour[LENS];
	char tar[LENS];
	char buffer[LENS];

	memset(buffer, 0, sizeof(buffer));
	dirptr = opendir(src);
	/*DIR* opendir (const char * path );*/
	strcpy(sour, src);
	strcpy(tar, des);
	while(dr_file = readdir(dirptr))
		/*struct dirent* readdir(DIR* dir_handle); */
	{
		//stat(dr_file->d_name, &s_file);
		if( (strcmp(dr_file->d_name, ".") == 0) || (strcmp(dr_file->d_name, "..") == 0 ))
			continue;
		if(dr_file->d_type == DT_DIR)
		{
			//printf("src:%s\ndes:%s\n",src, des);
			//printf("tar:%s\nsource:%s\n",tar, sour);
			//printf("i am in DT_DIR:%d\n",DT_DIR);

			strcat(tar, "/");
			strcat(tar, dr_file->d_name);
			strcat(sour, "/");
			strcat(sour, dr_file->d_name);
			
			lstat(sour, &s_file);
			mkdir(tar, s_file.st_mode);
			
			//printf("tar:%s\n",tar);
			//printf("sour:%s\n",sour);
			cpd(sour, tar);
			//timeSrc.actime = s_file.st_atime;
			//timeSrc.modtime = s_file.st_mtime;
			//utime(des, &timeSrc);
			times[0].tv_sec = s_file.st_atime;
			times[0].tv_usec = 0;
			times[1].tv_sec = s_file.st_mtime;
			times[1].tv_usec = 0;
			lutimes(tar, times);
			
			strcpy(sour, src);
			strcpy(tar, des);
		}
		else if(dr_file->d_type == DT_LNK)
		{
			strcat(tar, "/");
			strcat(tar, dr_file->d_name);
			strcat(sour, "/");
			strcat(sour, dr_file->d_name);
			
			//printf("src:%s\ndes:%s\n",src, des);
			//printf("tar:%s\nsource:%s\n",tar, sour);
			//printf("i am in DT_LNK:%d\n",DT_LNK);

			lstat(sour, &s_file);
			readlink(sour, buffer, sizeof(buffer));
			/*ssize_t readlink(const char *path, char *buf, size_t bufsiz);*/
			//printf("\n\nsource:%s\nbuffer:%s\ntarget:%s\n\n",sour, buffer, tar);
			if(symlink(buffer, tar) == -1)
			/*
			int symlink(
			const char *oldpath, //已有的文件路径
			const char *newpath//新建的符号链接文件路径
			);
			*/
			{
				perror("symlink");
				exit(0);
			}
			//timeSrc.actime = s_file.st_atime;
			//timeSrc.modtime = s_file.st_mtime;
			//utime(tar, &timeSrc);	
			times[0].tv_sec = s_file.st_atime;
			times[0].tv_usec = 0;
			times[1].tv_sec = s_file.st_mtime;
			times[1].tv_usec = 0;
			lutimes(tar, times);

		}	
		else
		{
			//printf("src:%s\ndes:%s\n",src, des);
			//printf("tar:%s\nsource:%s\n",tar, sour);		
			//printf("i am in else\n");		
			strcat(tar, "/");
			strcat(tar, dr_file->d_name);
			strcat(sour, "/");
			strcat(sour, dr_file->d_name);
			cpf(sour, tar);
			strcpy(sour, src);
			strcpy(tar, des);
		}
	//printf("\n");
	}
}

void cpf(char *src, char *des)
{

	struct utimbuf timeSrc;
	struct stat s_file;
	int fd,fdd;
	char buf[LENS];
	int once_bits;
	int count = 0;

	int tmp = lstat(src, &s_file);
	//printf("src:%s\ndes:%s\n",src, des);
	//printf("link?%d\n",S_ISLNK(s_file.st_mode));
	if(S_ISLNK(s_file.st_mode))
	{
		symlink(src,des);
	}
	else if(s_file.st_nlink>1)
	{
		link(src, des);
		/*
		int link(
		const char *oldpath, //已有的文件路径。
		const char *newpath//新建的硬链接文件路径。
		);
		返回值：成功返回0，错误返回-1。
		*/
	}
	else
	{
		fd = open(src, O_RDONLY);
		fdd = creat(des, s_file.st_mode);
		while((once_bits = read(fd, buf, 1024)) > 0)
		{	
			write(fdd, buf, once_bits);
		}
		close(fd);
		close(fdd);
		timeSrc.actime = s_file.st_atime;
		timeSrc.modtime = s_file.st_mtime;
		utime(des , &timeSrc);
	}

}


