#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <Windows.h>
#include <windowsx.h>

#define PATH_SIZE 260

BOOL IsFile(WIN32_FIND_DATA* lpFindData) {
	return (lpFindData->dwFileAttributes ^ FILE_ATTRIBUTE_DIRECTORY) != 0;
}

BOOL IsDir(WIN32_FIND_DATA* lpFindData) {
	return((lpFindData->dwFileAttributes ^ FILE_ATTRIBUTE_DIRECTORY) == 0);
}

BOOL IsChildDir(WIN32_FIND_DATA* lpFindData) {
	return((lpFindData->dwFileAttributes ^ FILE_ATTRIBUTE_DIRECTORY) == 0 &&
		lstrcmp(lpFindData->cFileName, ".") != 0 &&
		lstrcmp(lpFindData->cFileName, "..") != 0);
}

BOOL GetParentDir(char filePath[], char fileDirPath[]) {
	int i, index;
	index = -1;
	for (i = PATH_SIZE; i >= 0; i--) {
		if (filePath[i] == '\\') {
			index = i - 2;
			break;
		}
	}
	if (index < 0) return FALSE;
	for (i = 0; i <= index; i++) {
		fileDirPath[i] = filePath[i];
	}
	return TRUE;
}

BOOL GetFileName(char filePath[], char fileName[]) {
	int i, index1, index2;
	index1 = index2 = -1;
	for (i = PATH_SIZE; i >= 0; i--) {
		if (filePath[i] == '\0') index2 = i;
		if (filePath[i] == '\\') {
			index1 = i + 1;
			break;
		}
	}
	if (index1 < 0 || index2 < 0) return FALSE;
	for (i = 0; i < (index2 - index1); i++) {
		fileName[i] = filePath[index1 + 1];
	}
	return TRUE;
}

BOOL GetFileTimeByPath(char path[], FILETIME* lpCreateTime, FILETIME* lpLastAcessTime, FILETIME* lpLastWriteTime) {
	HANDLE hd = CreateFile(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_DELETE, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (hd == INVALID_HANDLE_VALUE) {
		printf("Failed to open dir: %s error: %d\n", path, GetLastError());
		return FALSE;
	}
	BOOL flag = GetFileTime(hd, lpCreateTime, lpLastAcessTime, lpLastWriteTime);
	CloseHandle(hd);
	return flag;
}

BOOL SetFileTimeByPath(char path[], FILETIME* lpCreateTime, FILETIME* lpLastAcessTime, FILETIME* lpLastWriteTime) {
	HANDLE hd = CreateFile(path, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_DELETE, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (hd == INVALID_HANDLE_VALUE) {
		printf("Failed to open dir: %s error: %d\n", path, GetLastError());
		return FALSE;
	}
	BOOL flag = SetFileTime(hd, lpCreateTime, lpLastAcessTime, lpLastWriteTime);
	CloseHandle(hd);
	return flag;
}

void copy(char srcpath[], char destpath[]) {
	HANDLE hfd_src, hfd_dest;
	WIN32_FIND_DATA wfd_src;
	FILETIME lpCreateTime, lpLastAcessTime, lpLastWriteTime;

	//�ж�Դ·�����ļ������ļ���
	if ((hfd_src = FindFirstFile(srcpath, &wfd_src)) == INVALID_HANDLE_VALUE) {
		printf("Failed to get SRC path's FIND_DATA: %s error: %d\n", srcpath, GetLastError());
		exit(-1);
	}
	if (IsDir(&wfd_src)) {//Դ·��Ϊ�ļ���
		BOOL createFlag = CreateDirectory(destpath, NULL);
		if (!createFlag) {
			printf("Failed to create directory: %s error: %d\n", destpath, GetLastError());
			exit(-1);
		}

		/*
		* ����Դ·���ļ����µ��������ݣ����и���
		*/
		char new_srcpath[PATH_SIZE], new_destpath[PATH_SIZE];
		WIN32_FIND_DATA wfd_ns;
		memset(new_srcpath, '\0', sizeof(new_srcpath));
		memset(new_destpath, '\0', sizeof(new_destpath));
		strcpy(new_srcpath, srcpath);
		strcpy(new_destpath, destpath);
		strcat(new_srcpath, "\\*");
		strcat(new_destpath, "\\");
		HANDLE hdfirst = FindFirstFile(new_srcpath, &wfd_ns);
		memset(new_srcpath, '\0', sizeof(new_srcpath));
		strcpy(new_srcpath, srcpath);
		strcat(new_srcpath, "\\");
		do{
			if (lstrcmp(wfd_ns.cFileName, ".") == 0 || lstrcmp(wfd_ns.cFileName, "..") == 0) continue;	//��Ϊ��Ŀ¼���߱�Ŀ¼��������ִ����һ��
			char tmp1[PATH_SIZE], tmp2[PATH_SIZE];
			memset(tmp1, '\0', sizeof(tmp1));
			memset(tmp2, '\0', sizeof(tmp2));
			strcpy(tmp1, new_srcpath);
			strcpy(tmp2, new_destpath);
			strcat(tmp1, wfd_ns.cFileName);
			strcat(tmp2, wfd_ns.cFileName);
			copy(tmp1, tmp2);
		} while (FindNextFile(hdfirst, &wfd_ns) != 0);

		/*
		* �޸��½����ļ�������
		*/
		GetFileTimeByPath(srcpath, &lpCreateTime, &lpLastAcessTime, &lpLastWriteTime);
		SetFileTimeByPath(destpath, &lpCreateTime, &lpLastAcessTime, &lpLastWriteTime);
		SetFileAttributes(destpath, wfd_src.dwFileAttributes);

		FindClose(hdfirst);
	}
	else {//Դ·��Ϊ�ļ�
		HANDLE hfd_src, hfd_dest;
		hfd_src = CreateFile(srcpath, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		hfd_dest = CreateFile(destpath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, hfd_src);
		DWORD filesize = wfd_src.nFileSizeLow*(MAXDWORD + 1) + wfd_src.nFileSizeLow;
		DWORD readsize, writesize;
		char* buf = new char[filesize + 1];
		ReadFile(hfd_src, buf, filesize, &readsize, NULL);
		if (readsize != filesize) {
			printf("Error occurred: readsize didn't match filesize\n");
			exit(-1);
		}
		WriteFile(hfd_dest, buf, readsize, &writesize, NULL);
		if (readsize != writesize) {
			printf("Error occurred: writesize didn't match readsize\n");
		}

		/*
		* �޸�Ŀ���ļ�����
		*/
		GetFileTime(hfd_src, &lpCreateTime, &lpLastAcessTime, &lpLastWriteTime);
		SetFileTime(hfd_dest, &lpCreateTime, &lpLastAcessTime, &lpLastWriteTime);
		SetFileAttributes(destpath, wfd_src.dwFileAttributes);

		CloseHandle(hfd_src);
		CloseHandle(hfd_dest);
	}

	FindClose(hfd_src);	//��β�������رմ򿪵�findfirstfile���
}


int main(int argc, char* argv[]) {
	if (argc < 3 || (strcmp(argv[1], "/?")) == 0 || (strcmp(argv[1], "/help")) == 0)
	{
		printf("Usage:    MyCopy.exe source_path dest_path\n    source path must match dest path\n");
	}
	copy(argv[1], argv[2]);
	printf("Copy completed\n");
	return 0;
}

