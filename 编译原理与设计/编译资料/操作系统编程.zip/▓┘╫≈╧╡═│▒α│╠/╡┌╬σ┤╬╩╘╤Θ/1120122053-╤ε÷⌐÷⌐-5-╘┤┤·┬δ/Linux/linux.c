#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <dirent.h>
#include <utime.h>
#include <time.h>

void myfcopy(char *src, char *des);
void mydcopy(char *src, char *des);

int main(int argc, char **argv)
{
	struct utimbuf timeby;
	struct stat ftype;
	if(argc != 3)
	{
		printf("command should be like 'cp src dir'\n");
		exit(0);	
	}
	else
	{
	//	struct stat ftype;
		int fd;
		if( lstat(argv[1],&ftype) == -1 )
		{	
			perror("lstat");
			exit(0);
		}
		if(S_ISDIR(ftype.st_mode))
		{
			mkdir(argv[2], ftype.st_mode)	;
			mydcopy(argv[1], argv[2]);
		}
		else 
		{
			myfcopy(argv[1], argv[2]);
		}
	}
	stat(argv[1], &ftype);
	timeby.actime = ftype.st_atime;
	timeby.modtime = ftype.st_mtime;
	utime(argv[2], &timeby);
	printf("cp has sucessed!\n");	
	return 0;
}

void mydcopy(char *src, char *des)
{
	DIR *dirptr = NULL;
	struct dirent *entry = NULL;
	struct stat ftype;
	char source[512];
	char target[512];
	char buffer[1024];
	struct utimbuf timeby;
	struct timeval times[2];
	memset(buffer, 0, sizeof(buffer));
	dirptr = opendir(src);
	strcpy(source, src);
	strcpy(target, des);
	while(entry = readdir(dirptr))
	{
		//stat(entry->d_name, &ftype);
		if( (strcmp(entry->d_name, ".") == 0) || (strcmp(entry->d_name, "..") == 0 ))
			continue;
		if(entry->d_type == DT_DIR)
		{
			strcat(target, "/");
			strcat(target, entry->d_name);
			strcat(source, "/");
			strcat(source, entry->d_name);
			
			lstat(source, &ftype);
			mkdir(target, ftype.st_mode);
			timeby.actime = ftype.st_atime;
			timeby.modtime = ftype.st_mtime;
			utime(des, &timeby);
			mydcopy(source, target);
			strcpy(source, src);
			strcpy(target, des);
		}
		else if(entry->d_type == DT_LNK)
		{
			strcat(target, "/");
			strcat(target, entry->d_name);
			strcat(source, "/");
			strcat(source, entry->d_name);
			
			lstat(source, &ftype);
			readlink(source, buffer, sizeof(buffer));
			if(symlink(buffer, target) == -1)
			{
				perror("symlink");
				exit(0);
			}		
			times[0].tv_sec = ftype.st_atime;
			times[0].tv_usec = 0;
			times[1].tv_sec = ftype.st_mtime;
			times[1].tv_usec = 0;
			lutimes(target, times);

		}	
		else
		{		
			strcat(target, "/");
			strcat(target, entry->d_name);
			strcat(source, "/");
			strcat(source, entry->d_name);
			myfcopy(source, target);
			strcpy(source, src);
			strcpy(target, des);
		}
	}
}

void myfcopy(char *src, char *des)
{
	struct utimbuf timeby;
	struct stat ftype;
	int fd,fdd;
	char buf[1024];
	int nbit;
	int count = 0;
	//struct timbuf timeby;
	if(lstat(src, &ftype) == -1)
	{
		perror("lstat");
		exit(0);
	}
	fd = open(src, O_RDONLY);
	fdd = creat(des, ftype.st_mode);
	while((nbit = read(fd, buf, 1024)) > 0)
	{
	//	count++;
	//	printf("count = %d\n",count);	
		write(fdd, buf, nbit);
	}
	close(fd);
	close(fdd);
	timeby.actime = ftype.st_atime;
	timeby.modtime = ftype.st_mtime;
	utime(des , &timeby);
}
