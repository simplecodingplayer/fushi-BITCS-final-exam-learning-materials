int main() {
  int a;

  a = MARS_GETI();
  a *= 10;
  MARS_PUTI(a);
  a ++;
  MARS_PUTI(a);
  return 0;
}

