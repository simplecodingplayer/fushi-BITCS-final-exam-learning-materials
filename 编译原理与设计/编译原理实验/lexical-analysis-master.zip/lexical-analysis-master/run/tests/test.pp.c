int main ( int a , int b ) 
 { 
 a = a & b ; 
 return a + b ; 
 } 
