int a = 0xA1Eull;
float b = 1.5e-4F;
char *s = "一个很长的字符串";
a += 2;
