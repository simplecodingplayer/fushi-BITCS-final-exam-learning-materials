module.exports = {
  lintOnSave: undefined,
  publicPath: './',
  outputDir: undefined,
  assetsDir: undefined,
  runtimeCompiler: undefined,
  productionSourceMap: undefined,
  parallel: false,
  css: undefined
}
